<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />

    @vite(['resources/css/app.css'])
</head>

<body class="font-sans antialiased">

    <div class="page-content relative w-full max-w-2xl px-6 lg:max-w-4xl mx-auto py-8">
        <h1 class="text-center">Social Sale Terms of Use</h1>
        <div class="post_content">
            <h2>1. Website Terms of service</h2>
            <p>1.1. Please read these Terms of Service (“Terms”, “Terms of Use”) carefully before using our Service
                operated by The Team of Facebook &amp; Instagram Shop, social-sale.rubic.chat (“us”, “we”, or “our”).
                Please, also read our Privacy Policy to understand, how we use the Personal information you provide to
                us.</p>
            <p>1.2. Your access to and use of the Site/Services is conditioned on your acceptance of and compliance with
                these Terms. These Terms apply to all visitors, users who access or use the Site/Services and
                Services.<br>
                1.3. By accessing or using the Site/Services you agree to be bound by these Terms. If you disagree with
                any part of the terms then you have not access the Site/Services.</p>
            <p>1.4. We reserve the right, in our sole discretion, to modify or replace any of these Terms of Use, or
                change, suspend, or discontinue the access to the Site/Services (including without limitation, the
                availability of any feature, database, or content) at any time by posting a notice through the
                Site/Services, via e-mail or by another appropriate means of electronic communication. We may also
                impose limits on certain features and services or restrict user access to parts or all of Site/Services
                without notice or liability. You agree that we will not be liable to you or any third party for any
                termination of your access to the Site/Services.</p>
            <p>1.5. While we will timely provide notice of modifications, it is also your responsibility to check these
                Terms of Service periodically for changes. Your continued use of the Site/Services following
                notification of any changes to these Terms of Use constitutes acceptance of those changes, which will
                apply to your continued use of the Site/Services going forward. Your use of the Site/Services is subject
                to the Terms of Use in effect at the time of such use.</p>
            <h2>2. Rules of Conduct</h2>
            <p>2.1. As a condition of use, you promise not to use the Site/Services for any purpose that is prohibited
                by these Terms of Service; You shall not: (i) take any action that imposes or may impose (as determined
                by us in our sole discretion) an unreasonable or disproportionately large load on our (or our third
                party providers’) infrastructure; (ii) interfere or attempt to interfere with the proper working of the
                Site/Services or any activities conducted on the Site/Services; (iii) bypass, circumvent or attempt to
                bypass or circumvent any measures we may use to prevent or restrict access to the Site/Services (or
                other accounts, computer systems or networks connected to the Site/Services); (iv) run any form of
                auto-responder or “spam” on the Site/Services; (v) use manual or automated software, devices, or other
                processes to “crawl” or “spider” any page of the Site/Services; (vi) harvest or scrape any content or
                personal data from the Site/Services; (vii) otherwise take any action in violation of our guidelines and
                policies. use software viruses or any other computer codes, files, or programs that are designed or
                intended to disrupt, damage, limit or interfere with the proper function of any software, hardware, or
                telecommunications equipment or to damage or obtain unauthorized access to any system, data, password or
                other information of ours or of any third party</p>
            <p>2.2. You shall not (directly or indirectly):</p>
            <ol style="list-style-type: lower-roman;">
                <li>decipher, decompile, disassemble, reverse engineer or otherwise attempt to derive any source code or
                    underlying ideas or algorithms of any part of the Site/Services (including without limitation any
                    application), except to the limited extent applicable laws specifically prohibit such
                    restriction,&nbsp;</li>
                <li>modify, translate, or otherwise create derivative works of any part of the Services,&nbsp;</li>
                <li>engage in or use any data mining, robots, scraping, or similar data gathering or extraction methods,
                    or&nbsp;</li>
                <li>copy, rent, lease, distribute, or otherwise transfer any of the rights that you receive hereunder.
                </li>
            </ol>
            <h2>3. Intellectual Property</h2>
            <p>3.1. The Website/Services name and logos are trademarks and service or brand identifier’s marks of us.
                Nothing in this Terms of Use or the Site/Services should be construed as granting, by implication,
                estoppel, or otherwise, any license or right to use any of our Trademarks displayed on the
                Site/Services, without our prior written permission in each instance. All goodwill generated from the
                use of o our Trademarks will inure to our exclusive benefit.</p>
            <p>3.2. You must not modify the physical or digital copies of any Content you print off or download in any
                way, and you must not use any illustrations, photographs, video or audio, or any graphics separately
                from any accompanying text.</p>
            <h2>4. Warranties</h2>
            <p>4.1. The access to the Site/Services is provided “as is”, “as available” but we do our best and taking
                all reasonably possible technical and legal measures to ensure that your use of our site is safe and to
                ensure the safety and legal use of the information that you provide.</p>
            <p>4.2. We are not responsible for the criminal, unlawful, negligent actions or inactivity of any third
                parties associated with the use of the Site/Services, in whatsoever such actions would be.</p>
            <p>4.3. In the event of a court case, it will be considered under the current legislation of Ukraine in the
                relevant court for the observance of jurisdiction.</p>
            <p>4.4. If any provision of these Terms of Service is found to be unenforceable or invalid, that provision
                will be limited or eliminated to the minimum extent necessary so that these Terms of Service will
                otherwise remain in full force and effect and enforceable. The failure of either party to exercise in
                any respect any right provided for herein shall not be deemed a waiver of any further rights hereunder.
                Our failure to enforce any part of these Terms of Service shall not constitute a waiver of our right to
                later enforce that or any other part of these Terms of Service. Waiver of compliance in any particular
                instance does not mean that we will waive compliance in the future. In order for any waiver of
                compliance with these Terms of Service to be binding, we must provide you with written notice of such
                waiver through one of our authorized representatives.</p>
            <h2>5. Limitation of Liability</h2>
            <p>5.1. To the fullest extent permitted by applicable law, in no event will us be liable to you on any legal
                theory for any incidental, direct, indirect, punitive, actual, consequential, special, exemplary, or
                other damages, including without limitation, loss of revenue or income, lost profits, pain, and
                suffering, emotional distress, cost of substitute goods or services, or similar damages suffered or
                incurred by you or any third party that arises in connection with the services (or the termination
                thereof for any reason), even if we have been advised of the possibility of such damages. To the fullest
                extent permitted by applicable law, We are not responsible or liable whatsoever in any manner for any
                content posted on or available through the services (including claims of infringement relating to that
                content), for your use of the services, or for the conduct of third parties on or through the services.
            </p>
            <h4>Force Majeure</h4>
            <p>5.2. We shall not be liable for any failure to perform our obligations hereunder where such failure
                results from any cause beyond our reasonable control.</p>
            <h2>6. Assignment</h2>
            <p>6.1. These Terms of Use are personal to you and are not assignable, transferable or sublicensable by you
                except with our prior written consent. We may assign, transfer or delegate any of our rights and
                obligations hereunder without consent.</p>
            <h2>7. Payments.</h2>
            <p>7.1. Paying Online with the Bank Card</p>
            <p>Our website is connected to the Internet acquiring, and you can pay for the Goods with your Visa,
                MasterCard, Maestro and MIR card. After your confirm the selected Goods, a secure window pops up showing
                the payment page of Paddle processing center, where you need to enter you bank card details. 3D Secure
                protocol is used for additional authentication of the card holder. If your bank supports this
                technology, you will be redirected to its server for additional identification. You can learn about the
                rules and methods of additional identification in the Bank, where you were issued your bank card.</p>
            <p>7.2. Safety Assurance</p>
            <p>7.2.1. Paddle processing center protects and processes your bank card details in compliance with PCI DSS
                3.2. The information is transferred to the payment gateway using SSL encryption. Further, the
                information is transmitted along secure bank networks featuring the highest security level. Paddle does
                not transfer your card details to us or any third parties. 3D Secure protocol is used for additional
                authentication of the card holder.</p>
            <p>7.2.2. If you have any questions about the payment you have made you may contact support of your payment
                service by paddle.com</p>
            <p>7.3. Online Payment Security</p>
            <p>7.3.1. The personal data your provide (name, address, telephone, e-mail, credit card number) are
                confidential information not to be disclosed. Your credit card details are transferred only in the
                encrypted form and are not stored in our web-server.</p>
            <p>7.3.2. We recommend that you should check in the dedicated web-page, if your web-browser is safe enough
                for online payments.</p>
            <p>7.3.3. Safety of online payment processing is guaranteed by Paddle. All payment card transactions are
                carried out in compliance with requirements of VISA International, MasterCard and other payment systems.
                For information transfer, special technologies designed to ensure safety of online card payments are
                used, with the data processed by the secure hi-tech server of the processing company.</p>
            <h2>8. Monthly Plan and Credits</h2>
            <p>8.1. Monthly Plan</p>
            <p>8.1.1. You have the option to select a monthly plan (“PRO Plan” or “Paid Plan”) from those posted on our
                Site. With a PRO Plan, you will have access to Auto Posts, Shoppable Posts, Scheduled Posts, and related
                features. All Members, you agree to monthly recurring billing in advance, starting on the date you sign
                up for a Paid Plan. Thereafter, billing occurs every 30 days. Note that your first payment for your Paid
                Plan may be prorated if you first started paying for any other recurring monthly plan before you signed
                up for your Paid Plan; thereafter, your payment dates will align, and you will be billed for the full
                billing cycle each month.</p>
            <p>8.1.2. You are allowed to cancel your Paid Plan at anytime, to do so you may contact us in advance of 3 business
                days.</p>
            <p>8.1.3. You are entitled to a refund of the last payment which invoiced in the recent 30 days of your Paid
                Plan from us. However, you will not be entitled to a refund which invoiced older than 30 days.</p>
            <p>8.2. Credits</p>
            <p>8.2.1. You may also buy credits to use the Service (“Credits”), as explained on our Site. You will have
                an opportunity to review current rates for Credits in your account prior to purchase. Credits purchased
                on or after May 15, 2019 roll over each month, and expire 12 months after purchase. Credits purchased
                before May 15, 2019 also roll over each month, and expired on May 15, 2020.</p>
            <p>8.2.2. Credits have no cash value, cannot be refunded or redeemed for cash, and represent a limited
                license to use the Service for the specified volume and type of service.</p>
            <h2>9. Closing Your Account</h2>
            <p>9.1. You or Facebook &amp; Instagram Shop may terminate the Agreement at any time and for any reason. You
                may do so by terminating your Facebook &amp; Instagram Shop account or we may do so with or without
                giving notice to you that we are terminating the Agreement. We may suspend the Service to you at any
                time, with or without cause. We won’t refund or reimburse you in any situation. If your account is
                inactive for 24 or more months, we may terminate your account and you won’t be entitled to a refund for
                any prepaid amounts or reimbursement for unused Pay as You Go Credits. Once your account is terminated,
                you acknowledge and agree that we may permanently delete your account and all the data associated with
                it, including your Campaigns. Your username may no longer be available for use on any future accounts
                and cannot be reclaimed.</p>
        </div>
    </div>
</body>

</html>
